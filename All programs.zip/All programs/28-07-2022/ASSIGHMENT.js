//**ASSIGHMENT**//
let x =100;
x+=50;
document.write("<br><b>(OUTPUT OF)+=:</b><br>",x);

let a =100;
a-=50;
document.write("<br><b>(OUTPUT OF)-=:</b><br>",a);

let b =100;
b*=50;
document.write("<br><b>(OUTPUT OF)*=:</b><br>",b);

let c =100;
c/=50;
document.write("<br><b>(OUTPUT OF)/=:</b><br>",c);

let p =100;
p%=50;
document.write("<br><b>(OUTPUT OF)%=:</b><br>",p);